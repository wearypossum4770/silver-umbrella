"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

class CssDependencyTemplate {
  // eslint-disable-next-line class-methods-use-this
  apply() {}

}

exports.default = CssDependencyTemplate;