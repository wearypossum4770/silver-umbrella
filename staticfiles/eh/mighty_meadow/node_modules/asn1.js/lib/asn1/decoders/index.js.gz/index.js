'use strict';

const decoders = exports;

decoders.der = require('./der');
decoders.pem = require('./pem');
