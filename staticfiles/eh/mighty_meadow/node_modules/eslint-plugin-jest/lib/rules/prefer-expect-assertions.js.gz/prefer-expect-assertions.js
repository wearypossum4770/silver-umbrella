"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _experimentalUtils = require("@typescript-eslint/experimental-utils");

var _utils = require("./utils");

const isExpectAssertionsOrHasAssertionsCall = expression => expression.type === _experimentalUtils.AST_NODE_TYPES.CallExpression && expression.callee.type === _experimentalUtils.AST_NODE_TYPES.MemberExpression && (0, _utils.isSupportedAccessor)(expression.callee.object, 'expect') && (0, _utils.isSupportedAccessor)(expression.callee.property) && ['assertions', 'hasAssertions'].includes((0, _utils.getAccessorValue)(expression.callee.property));

const isFirstLineExprStmt = functionBody => functionBody[0] && functionBody[0].type === _experimentalUtils.AST_NODE_TYPES.ExpressionStatement;

const suggestRemovingExtraArguments = (args, extraArgsStartAt) => ({
  messageId: 'suggestRemovingExtraArguments',
  fix: fixer => fixer.removeRange([args[extraArgsStartAt].range[0] - Math.sign(extraArgsStartAt), args[args.length - 1].range[1]])
});

const suggestions = [['suggestAddingHasAssertions', 'expect.hasAssertions();'], ['suggestAddingAssertions', 'expect.assertions();']];

var _default = (0, _utils.createRule)({
  name: __filename,
  meta: {
    docs: {
      category: 'Best Practices',
      description: 'Suggest using `expect.assertions()` OR `expect.hasAssertions()`',
      recommended: false,
      suggestion: true
    },
    messages: {
      hasAssertionsTakesNoArguments: '`expect.hasAssertions` expects no arguments',
      assertionsRequiresOneArgument: '`expect.assertions` excepts a single argument of type number',
      assertionsRequiresNumberArgument: 'This argument should be a number',
      haveExpectAssertions: 'Every test should have either `expect.assertions(<number of assertions>)` or `expect.hasAssertions()` as its first expression',
      suggestAddingHasAssertions: 'Add `expect.hasAssertions()`',
      suggestAddingAssertions: 'Add `expect.assertions(<number of assertions>)`',
      suggestRemovingExtraArguments: 'Remove extra arguments'
    },
    type: 'suggestion',
    schema: [{
      type: 'object',
      properties: {
        onlyFunctionsWithAsyncKeyword: {
          type: 'boolean'
        }
      },
      additionalProperties: false
    }]
  },
  defaultOptions: [{
    onlyFunctionsWithAsyncKeyword: false
  }],

  create(context, [options]) {
    return {
      'CallExpression[callee.name=/^(it|test)$/][arguments.1.body.body]'(node) {
        if (options.onlyFunctionsWithAsyncKeyword && !node.arguments[1].async) {
          return;
        }

        const testFuncBody = node.arguments[1].body.body;

        if (!isFirstLineExprStmt(testFuncBody)) {
          context.report({
            messageId: 'haveExpectAssertions',
            node,
            suggest: suggestions.map(([messageId, text]) => ({
              messageId,
              fix: fixer => fixer.insertTextBeforeRange([node.arguments[1].body.range[0] + 1, node.arguments[1].body.range[1]], text)
            }))
          });
          return;
        }

        const testFuncFirstLine = testFuncBody[0].expression;

        if (!isExpectAssertionsOrHasAssertionsCall(testFuncFirstLine)) {
          context.report({
            messageId: 'haveExpectAssertions',
            node,
            suggest: suggestions.map(([messageId, text]) => ({
              messageId,
              fix: fixer => fixer.insertTextBefore(testFuncBody[0], text)
            }))
          });
          return;
        }

        if ((0, _utils.isSupportedAccessor)(testFuncFirstLine.callee.property, 'hasAssertions')) {
          if (testFuncFirstLine.arguments.length) {
            context.report({
              messageId: 'hasAssertionsTakesNoArguments',
              node: testFuncFirstLine.callee.property,
              suggest: [suggestRemovingExtraArguments(testFuncFirstLine.arguments, 0)]
            });
          }

          return;
        }

        if (!(0, _utils.hasOnlyOneArgument)(testFuncFirstLine)) {
          let {
            loc
          } = testFuncFirstLine.callee.property;
          const suggest = [];

          if (testFuncFirstLine.arguments.length) {
            loc = testFuncFirstLine.arguments[1].loc;
            suggest.push(suggestRemovingExtraArguments(testFuncFirstLine.arguments, 1));
          }

          context.report({
            messageId: 'assertionsRequiresOneArgument',
            suggest,
            loc
          });
          return;
        }

        const [arg] = testFuncFirstLine.arguments;

        if (arg.type === _experimentalUtils.AST_NODE_TYPES.Literal && typeof arg.value === 'number' && Number.isInteger(arg.value)) {
          return;
        }

        context.report({
          messageId: 'assertionsRequiresNumberArgument',
          node: arg
        });
      }

    };
  }

});

exports.default = _default;