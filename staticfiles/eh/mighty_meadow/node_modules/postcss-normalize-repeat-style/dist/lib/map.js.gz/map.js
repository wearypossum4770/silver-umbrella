'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = [['repeat-x', ['repeat', 'no-repeat']], ['repeat-y', ['no-repeat', 'repeat']], ['repeat', ['repeat', 'repeat']], ['space', ['space', 'space']], ['round', ['round', 'round']], ['no-repeat', ['no-repeat', 'no-repeat']]];
module.exports = exports['default'];