import { Dictionary } from './common-types';
export declare function applyExtends(config: Dictionary, cwd: string, mergeExtends?: boolean): Dictionary;
