export declare function argsert(callerArguments: any[], length?: number): void;
export declare function argsert(expected: string, callerArguments: any[], length?: number): void;
