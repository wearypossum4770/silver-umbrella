export declare function getProcessArgvWithoutBin(): string[];
export declare function getProcessArgvBin(): string;
