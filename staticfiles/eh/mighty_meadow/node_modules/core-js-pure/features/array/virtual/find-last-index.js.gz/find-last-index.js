require('../../../modules/esnext.array.find-last-index');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').findLastIndex;
