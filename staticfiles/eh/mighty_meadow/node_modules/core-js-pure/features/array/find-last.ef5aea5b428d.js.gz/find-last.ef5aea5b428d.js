require('../../modules/esnext.array.find-last');
var entryUnbind = require('../../internals/entry-unbind');

module.exports = entryUnbind('Array', 'findLast');
