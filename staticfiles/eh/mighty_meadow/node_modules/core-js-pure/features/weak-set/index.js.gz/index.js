var parent = require('../../es/weak-set');
require('../../modules/esnext.weak-set.add-all');
require('../../modules/esnext.weak-set.delete-all');
require('../../modules/esnext.weak-set.from');
require('../../modules/esnext.weak-set.of');

module.exports = parent;
