require('../../modules/es.data-view');
require('../../modules/es.object.to-string');
var path = require('../../internals/path');

module.exports = path.DataView;
