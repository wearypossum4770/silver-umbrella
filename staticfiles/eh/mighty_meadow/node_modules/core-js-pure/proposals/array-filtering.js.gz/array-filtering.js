// https://github.com/tc39/proposal-array-filtering
require('../modules/esnext.array.filter-out');
require('../modules/esnext.typed-array.filter-out');
