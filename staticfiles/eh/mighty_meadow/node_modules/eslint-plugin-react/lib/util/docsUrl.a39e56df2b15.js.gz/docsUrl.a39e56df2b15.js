'use strict';

function docsUrl(ruleName) {
  return `https://github.com/yannickcr/eslint-plugin-react/tree/master/docs/rules/${ruleName}.md`;
}

module.exports = docsUrl;
