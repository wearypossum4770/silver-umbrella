require('../../modules/es.object.to-string');
require('../../modules/es.string.iterator');
require('../../modules/esnext.iterator.constructor');
require('../../modules/esnext.iterator.from');
require('../../modules/web.dom-collections.iterator');

var path = require('../../internals/path');

module.exports = path.Iterator.from;
