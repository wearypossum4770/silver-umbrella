var parent = require('../../es/typed-array');
require('../../modules/es.map');
require('../../modules/esnext.typed-array.at');
require('../../modules/esnext.typed-array.filter-out');
require('../../modules/esnext.typed-array.find-last');
require('../../modules/esnext.typed-array.find-last-index');
require('../../modules/esnext.typed-array.unique-by');

module.exports = parent;
