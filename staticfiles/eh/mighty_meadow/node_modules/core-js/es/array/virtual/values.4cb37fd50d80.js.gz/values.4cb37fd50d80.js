require('../../../modules/es.array.iterator');
var entryVirtual = require('../../../internals/entry-virtual');

module.exports = entryVirtual('Array').values;
