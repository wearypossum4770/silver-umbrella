require('../proposals/efficient-64-bit-arithmetic');
require('../proposals/string-at');
require('../proposals/url');
var parent = require('./1');

module.exports = parent;
