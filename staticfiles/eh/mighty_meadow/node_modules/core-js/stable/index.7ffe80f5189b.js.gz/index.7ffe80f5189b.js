require('../es');
require('../web');
var path = require('../internals/path');

module.exports = path;
