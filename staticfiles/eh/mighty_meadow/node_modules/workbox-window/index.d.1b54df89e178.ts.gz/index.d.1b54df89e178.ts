import { messageSW } from './messageSW.js';
import { Workbox } from './Workbox.js';
import './_version.js';
/**
 * @module workbox-window
 */
export { Workbox, messageSW, };
