"use strict";

var copyPrototype = require("./copy-prototype");

module.exports = copyPrototype(String.prototype);
