"use strict";

var copyPrototype = require("./copy-prototype");

module.exports = copyPrototype(Function.prototype);
