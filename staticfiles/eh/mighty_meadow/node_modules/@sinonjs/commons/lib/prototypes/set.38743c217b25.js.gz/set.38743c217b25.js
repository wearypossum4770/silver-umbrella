"use strict";

var copyPrototype = require("./copy-prototype");

module.exports = copyPrototype(Set.prototype);
