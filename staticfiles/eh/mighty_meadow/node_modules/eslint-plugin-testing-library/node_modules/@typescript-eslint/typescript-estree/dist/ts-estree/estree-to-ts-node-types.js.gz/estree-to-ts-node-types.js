"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const types_1 = require("@typescript-eslint/types");
//# sourceMappingURL=estree-to-ts-node-types.js.map