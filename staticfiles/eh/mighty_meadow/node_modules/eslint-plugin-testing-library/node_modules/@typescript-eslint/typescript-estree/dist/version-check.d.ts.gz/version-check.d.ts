declare const typescriptVersionIsAtLeast: Record<"4.0" | "3.7" | "3.8" | "3.9", boolean>;
export { typescriptVersionIsAtLeast };
//# sourceMappingURL=version-check.d.ts.map