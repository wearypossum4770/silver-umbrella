"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.TSESTree = exports.AST_TOKEN_TYPES = exports.AST_NODE_TYPES = void 0;
var ast_node_types_1 = require("./ast-node-types");
Object.defineProperty(exports, "AST_NODE_TYPES", { enumerable: true, get: function () { return ast_node_types_1.AST_NODE_TYPES; } });
var ast_token_types_1 = require("./ast-token-types");
Object.defineProperty(exports, "AST_TOKEN_TYPES", { enumerable: true, get: function () { return ast_token_types_1.AST_TOKEN_TYPES; } });
__exportStar(require("./lib"), exports);
__exportStar(require("./parser-options"), exports);
exports.TSESTree = __importStar(require("./ts-estree"));
//# sourceMappingURL=index.js.map