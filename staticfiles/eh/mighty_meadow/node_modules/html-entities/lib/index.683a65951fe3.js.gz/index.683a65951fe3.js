"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var xml_entities_1 = require("./xml-entities");
exports.XmlEntities = xml_entities_1.XmlEntities;
var html4_entities_1 = require("./html4-entities");
exports.Html4Entities = html4_entities_1.Html4Entities;
var html5_entities_1 = require("./html5-entities");
exports.Html5Entities = html5_entities_1.Html5Entities;
exports.AllHtmlEntities = html5_entities_1.Html5Entities;
