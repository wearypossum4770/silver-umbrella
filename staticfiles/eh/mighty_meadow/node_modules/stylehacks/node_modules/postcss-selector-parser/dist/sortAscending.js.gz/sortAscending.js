"use strict";

exports.__esModule = true;
exports.default = sortAscending;
function sortAscending(list) {
    return list.sort(function (a, b) {
        return a - b;
    });
};
module.exports = exports["default"];