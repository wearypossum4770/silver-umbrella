'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
const BODY = exports.BODY = 'body';
const HTML = exports.HTML = 'html';