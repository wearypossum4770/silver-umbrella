import * as prettyFormat from 'pretty-format'

export function prettyDOM(
  dom?: Element | HTMLDocument,
  maxLength?: number,
  options?: prettyFormat.OptionsReceived,
): string | false
export function logDOM(
  dom?: Element | HTMLDocument,
  maxLength?: number,
  options?: prettyFormat.OptionsReceived,
): void
export {prettyFormat}
