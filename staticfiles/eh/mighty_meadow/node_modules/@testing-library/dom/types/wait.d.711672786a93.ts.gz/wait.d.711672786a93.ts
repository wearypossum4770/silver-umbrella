/**
 * @deprecated `wait` has been deprecated and replaced by `waitFor` instead.
 * In most cases you should be able to find/replace `wait` with `waitFor`.
 * Learn more: https://testing-library.com/docs/dom-testing-library/api-async#waitfor.
 */
export function wait(
  callback?: () => void,
  options?: {
    timeout?: number
    interval?: number
  },
): Promise<void>
