import {waitForOptions} from './wait-for'

/**
 * @deprecated `waitForDomChange` has been deprecated.
 * Use `waitFor` instead: https://testing-library.com/docs/dom-testing-library/api-async#waitfor.
 */
export function waitForDomChange(options?: waitForOptions): Promise<any>
