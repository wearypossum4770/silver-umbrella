"use strict";

var _interopRequireWildcard = require("@babel/runtime/helpers/interopRequireWildcard");

var extensions = _interopRequireWildcard(require("./matchers"));

expect.extend(extensions);