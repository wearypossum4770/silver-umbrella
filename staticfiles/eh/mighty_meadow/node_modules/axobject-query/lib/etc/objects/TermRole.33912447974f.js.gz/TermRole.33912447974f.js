"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports["default"] = void 0;
var TermRole = {
  relatedConcepts: [{
    module: 'ARIA',
    concept: {
      name: 'term'
    }
  }],
  type: 'structure'
};
var _default = TermRole;
exports["default"] = _default;