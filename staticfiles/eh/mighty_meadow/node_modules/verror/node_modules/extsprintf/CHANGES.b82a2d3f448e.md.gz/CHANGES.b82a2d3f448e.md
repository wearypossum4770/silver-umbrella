# Changelog

## Not yet released

None yet.

## v1.4.0

* #13 could provide better error messages for programmer errors
* #14 bring extsprintf into the modern world
