import { insertedIntoFocusOrder } from '../commons/dom';

function insertedIntoFocusOrderMatches(node) {
	return insertedIntoFocusOrder(node);
}

export default insertedIntoFocusOrderMatches;
