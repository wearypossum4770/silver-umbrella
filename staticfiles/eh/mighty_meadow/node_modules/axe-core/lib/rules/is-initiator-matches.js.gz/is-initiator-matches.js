function isInitiatorMatches(node, virtualNode, context) {
	return context.initiator;
}

export default isInitiatorMatches;
