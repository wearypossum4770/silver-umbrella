# `thenable.finally` _(ext/thenable\_/finally)_

`finally` method for any _thenable_ input

```javascript
const finally = require("ext/thenable_/finally");

finally.call(thenable, () => console.log("Thenable resolved"));
```
