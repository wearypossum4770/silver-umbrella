# `Function.identity` _(ext/function/identity)_

Returns input argument.

```javascript
const identity = require("ext/function/identity");

identity("foo"); // "foo"
```
