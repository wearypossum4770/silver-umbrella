"use strict";

describe("string_/includes/implementation", function () {
	require("./_tests")(require("../../../string_/includes"));
});
