import { Queue } from './Queue.js';
import { BackgroundSyncPlugin } from './BackgroundSyncPlugin.js';
import './_version.js';
/**
 * @module workbox-background-sync
 */
export { Queue, BackgroundSyncPlugin, };
