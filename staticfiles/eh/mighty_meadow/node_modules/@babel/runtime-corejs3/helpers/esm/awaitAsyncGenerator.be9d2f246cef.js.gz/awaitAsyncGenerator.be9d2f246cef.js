import AwaitValue from "@babel/runtime-corejs3/helpers/esm/AwaitValue";
export default function _awaitAsyncGenerator(value) {
  return new AwaitValue(value);
}