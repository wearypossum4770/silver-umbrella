import _Object$setPrototypeOf from "@babel/runtime-corejs3/core-js/object/set-prototype-of";
export default function _setPrototypeOf(o, p) {
  _setPrototypeOf = _Object$setPrototypeOf || function _setPrototypeOf(o, p) {
    o.__proto__ = p;
    return o;
  };

  return _setPrototypeOf(o, p);
}