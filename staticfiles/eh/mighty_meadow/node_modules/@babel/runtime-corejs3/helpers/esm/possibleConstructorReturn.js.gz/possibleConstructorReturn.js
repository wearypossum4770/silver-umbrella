import _typeof from "@babel/runtime-corejs3/helpers/esm/typeof";
import assertThisInitialized from "@babel/runtime-corejs3/helpers/esm/assertThisInitialized";
export default function _possibleConstructorReturn(self, call) {
  if (call && (_typeof(call) === "object" || typeof call === "function")) {
    return call;
  }

  return assertThisInitialized(self);
}