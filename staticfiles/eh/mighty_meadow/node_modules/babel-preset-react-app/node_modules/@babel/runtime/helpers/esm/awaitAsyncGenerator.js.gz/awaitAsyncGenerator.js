import AwaitValue from "@babel/runtime/helpers/esm/AwaitValue";
export default function _awaitAsyncGenerator(value) {
  return new AwaitValue(value);
}