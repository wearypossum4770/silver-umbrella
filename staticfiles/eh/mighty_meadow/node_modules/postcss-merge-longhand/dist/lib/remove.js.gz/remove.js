"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.default = remove;
function remove(node) {
    return node.remove();
}
module.exports = exports["default"];