# Installation
> `npm install --save @types/resolve`

# Summary
This package contains type definitions for resolve (https://github.com/substack/node-resolve).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped.git/tree/master/types/resolve

Additional Details
 * Last updated: Tue, 08 May 2018 17:01:00 GMT
 * Dependencies: node
 * Global values: none

# Credits
These definitions were written by Mario Nebl <https://github.com/marionebl>, Klaus Meinhardt <https://github.com/ajafff>.
