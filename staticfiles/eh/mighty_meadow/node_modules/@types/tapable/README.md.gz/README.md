# Installation
> `npm install --save @types/tapable`

# Summary
This package contains type definitions for tapable (https://github.com/webpack/tapable.git).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/tapable.

### Additional Details
 * Last updated: Tue, 16 Jun 2020 20:54:22 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [e-cloud](https://github.com/e-cloud), and [John Reilly](https://github.com/johnnyreilly).
