# Installation
> `npm install --save @types/uglify-js`

# Summary
This package contains type definitions for UglifyJS (https://github.com/mishoo/UglifyJS).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/uglify-js.

### Additional Details
 * Last updated: Sun, 07 Feb 2021 06:53:27 GMT
 * Dependencies: [@types/source-map](https://npmjs.com/package/@types/source-map)
 * Global values: none

# Credits
These definitions were written by [Alan Agius](https://github.com/alan-agius4), [Tanguy Krotoff](https://github.com/tkrotoff), [John Reilly](https://github.com/johnnyreilly), and [Piotr Błażejewicz](https://github.com/peterblazejewicz).
