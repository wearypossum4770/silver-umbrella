import Source = require('./Source');

declare class SizeOnlySource extends Source {
    constructor(size: number);
}

export = SizeOnlySource;
