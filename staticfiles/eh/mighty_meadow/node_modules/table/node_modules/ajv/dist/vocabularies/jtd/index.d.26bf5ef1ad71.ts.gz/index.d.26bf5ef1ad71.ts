import type { Vocabulary } from "../../types";
declare const jtdVocabulary: Vocabulary;
export default jtdVocabulary;
