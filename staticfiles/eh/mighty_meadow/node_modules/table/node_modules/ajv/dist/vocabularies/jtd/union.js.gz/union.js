"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const code_1 = require("../code");
const def = {
    keyword: "union",
    schemaType: "array",
    trackErrors: true,
    code: code_1.validateUnion,
};
exports.default = def;
//# sourceMappingURL=union.js.map