import type { SchemaObjCxt } from "..";
import type { JSONType } from "../rules";
import { Name } from "../codegen";
export declare function schemaKeywords(it: SchemaObjCxt, types: JSONType[], typeErrors: boolean, errsCount?: Name): void;
