import type { AddedKeywordDefinition } from "../../types";
import type { SchemaObjCxt } from "..";
import type { JSONType } from "../rules";
export declare function keywordCode(it: SchemaObjCxt, keyword: string, def: AddedKeywordDefinition, ruleType?: JSONType): void;
