import { Formatter } from './Formatter';
declare function createRawFormatter(): Formatter;
export { createRawFormatter };
