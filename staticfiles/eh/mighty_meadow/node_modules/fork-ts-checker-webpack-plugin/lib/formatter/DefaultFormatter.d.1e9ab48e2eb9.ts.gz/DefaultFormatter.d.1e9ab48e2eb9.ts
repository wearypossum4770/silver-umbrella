import { Formatter } from './Formatter';
declare function createDefaultFormatter(): Formatter;
export { createDefaultFormatter };
