import { Formatter } from './Formatter';
/**
 * TODO: maybe we should not treat internal errors as issues
 */
declare function createInternalFormatter(): Formatter;
export { createInternalFormatter };
