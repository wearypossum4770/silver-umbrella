'use strict';

function _jestMock() {
  const data = _interopRequireDefault(require('jest-mock'));

  _jestMock = function () {
    return data;
  };

  return data;
}

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {default: obj};
}
