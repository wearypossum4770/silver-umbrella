import * as fs from 'fs';

export type Stats = fs.Stats;
export type ErrnoException = NodeJS.ErrnoException;
