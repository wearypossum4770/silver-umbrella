/// <reference types="node" />
import * as fs from 'fs';
export declare type Stats = fs.Stats;
export declare type ErrnoException = NodeJS.ErrnoException;
//# sourceMappingURL=index.d.ts.map