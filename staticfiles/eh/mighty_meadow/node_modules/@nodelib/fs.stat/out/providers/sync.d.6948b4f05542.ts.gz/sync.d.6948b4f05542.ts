import Settings from '../settings';
import { Stats } from '../types';
export declare function read(path: string, settings: Settings): Stats;
//# sourceMappingURL=sync.d.ts.map