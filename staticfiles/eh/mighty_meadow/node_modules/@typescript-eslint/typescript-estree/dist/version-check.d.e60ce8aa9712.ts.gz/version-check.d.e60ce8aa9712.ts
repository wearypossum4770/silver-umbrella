declare const typescriptVersionIsAtLeast: Record<"3.7" | "3.8" | "3.9" | "4.0", boolean>;
export { typescriptVersionIsAtLeast };
//# sourceMappingURL=version-check.d.ts.map