import * as ts from 'typescript';
import { Extra } from '../parser-options';
declare function createSourceFile(code: string, extra: Extra): ts.SourceFile;
export { createSourceFile };
//# sourceMappingURL=createSourceFile.d.ts.map