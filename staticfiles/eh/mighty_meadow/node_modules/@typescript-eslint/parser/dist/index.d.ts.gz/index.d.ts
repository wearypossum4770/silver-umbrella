export { parse, parseForESLint, ParserOptions } from './parser';
export { ParserServices, clearCaches, } from '@typescript-eslint/typescript-estree';
export declare const version: string;
//# sourceMappingURL=index.d.ts.map