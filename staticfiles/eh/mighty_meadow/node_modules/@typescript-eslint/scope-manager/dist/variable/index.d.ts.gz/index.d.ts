export { ESLintScopeVariable } from './ESLintScopeVariable';
export { ImplicitLibVariable, ImplicitLibVariableOptions, } from './ImplicitLibVariable';
export { Variable } from './Variable';
//# sourceMappingURL=index.d.ts.map