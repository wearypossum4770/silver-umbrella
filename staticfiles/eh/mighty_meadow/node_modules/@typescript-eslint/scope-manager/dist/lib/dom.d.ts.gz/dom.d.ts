import { ImplicitLibVariableOptions } from '../variable';
export declare const dom: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=dom.d.ts.map