"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.es2020_sharedmemory = void 0;
exports.es2020_sharedmemory = {
    Atomics: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'Atomics',
    },
};
//# sourceMappingURL=es2020.sharedmemory.js.map