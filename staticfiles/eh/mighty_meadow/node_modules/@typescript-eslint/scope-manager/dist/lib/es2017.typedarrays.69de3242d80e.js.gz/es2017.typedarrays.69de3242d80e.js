"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.es2017_typedarrays = void 0;
exports.es2017_typedarrays = {
    Int8ArrayConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'Int8ArrayConstructor',
    },
    Uint8ArrayConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'Uint8ArrayConstructor',
    },
    Uint8ClampedArrayConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'Uint8ClampedArrayConstructor',
    },
    Int16ArrayConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'Int16ArrayConstructor',
    },
    Uint16ArrayConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'Uint16ArrayConstructor',
    },
    Int32ArrayConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'Int32ArrayConstructor',
    },
    Uint32ArrayConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'Uint32ArrayConstructor',
    },
    Float32ArrayConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'Float32ArrayConstructor',
    },
    Float64ArrayConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'Float64ArrayConstructor',
    },
};
//# sourceMappingURL=es2017.typedarrays.js.map