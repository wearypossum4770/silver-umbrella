"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.webworker_importscripts = void 0;
exports.webworker_importscripts = {};
//# sourceMappingURL=webworker.importscripts.js.map