"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.esnext_full = void 0;
const esnext_1 = require("./esnext");
const dom_1 = require("./dom");
const webworker_importscripts_1 = require("./webworker.importscripts");
const scripthost_1 = require("./scripthost");
const dom_iterable_1 = require("./dom.iterable");
exports.esnext_full = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, esnext_1.esnext), dom_1.dom), webworker_importscripts_1.webworker_importscripts), scripthost_1.scripthost), dom_iterable_1.dom_iterable);
//# sourceMappingURL=esnext.full.js.map