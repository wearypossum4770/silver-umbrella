"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.es2020_string = void 0;
const es2015_iterable_1 = require("./es2015.iterable");
exports.es2020_string = Object.assign(Object.assign({}, es2015_iterable_1.es2015_iterable), { String: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'String',
    } });
//# sourceMappingURL=es2020.string.js.map