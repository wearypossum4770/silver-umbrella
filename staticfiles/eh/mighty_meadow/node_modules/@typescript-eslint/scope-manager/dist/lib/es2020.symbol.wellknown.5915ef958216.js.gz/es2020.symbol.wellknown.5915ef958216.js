"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.es2020_symbol_wellknown = void 0;
const es2015_iterable_1 = require("./es2015.iterable");
const es2015_symbol_1 = require("./es2015.symbol");
exports.es2020_symbol_wellknown = Object.assign(Object.assign(Object.assign({}, es2015_iterable_1.es2015_iterable), es2015_symbol_1.es2015_symbol), { SymbolConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'SymbolConstructor',
    }, RegExp: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'RegExp',
    } });
//# sourceMappingURL=es2020.symbol.wellknown.js.map