import { ImplicitLibVariableOptions } from '../variable';
export declare const esnext_weakref: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=esnext.weakref.d.ts.map