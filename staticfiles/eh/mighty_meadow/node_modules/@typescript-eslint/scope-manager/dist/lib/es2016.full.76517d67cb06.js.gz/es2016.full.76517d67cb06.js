"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.es2016_full = void 0;
const es2016_1 = require("./es2016");
const dom_1 = require("./dom");
const webworker_importscripts_1 = require("./webworker.importscripts");
const scripthost_1 = require("./scripthost");
const dom_iterable_1 = require("./dom.iterable");
exports.es2016_full = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, es2016_1.es2016), dom_1.dom), webworker_importscripts_1.webworker_importscripts), scripthost_1.scripthost), dom_iterable_1.dom_iterable);
//# sourceMappingURL=es2016.full.js.map