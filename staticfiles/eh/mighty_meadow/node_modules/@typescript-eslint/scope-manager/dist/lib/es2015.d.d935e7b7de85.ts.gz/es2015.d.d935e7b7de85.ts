import { ImplicitLibVariableOptions } from '../variable';
export declare const es2015: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2015.d.ts.map