import { ImplicitLibVariableOptions } from '../variable';
export declare const es2015_promise: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2015.promise.d.ts.map