import { ImplicitLibVariableOptions } from '../variable';
export declare const es2015_proxy: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2015.proxy.d.ts.map