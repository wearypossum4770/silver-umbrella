"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.webworker_iterable = void 0;
exports.webworker_iterable = {
    Cache: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'Cache',
    },
    CanvasPathDrawingStyles: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'CanvasPathDrawingStyles',
    },
    DOMStringList: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'DOMStringList',
    },
    FileList: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'FileList',
    },
    FormData: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'FormData',
    },
    Headers: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'Headers',
    },
    IDBDatabase: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'IDBDatabase',
    },
    IDBObjectStore: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'IDBObjectStore',
    },
    URLSearchParams: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'URLSearchParams',
    },
    WEBGL_draw_buffers: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'WEBGL_draw_buffers',
    },
    WebGL2RenderingContextBase: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'WebGL2RenderingContextBase',
    },
    WebGL2RenderingContextOverloads: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'WebGL2RenderingContextOverloads',
    },
    WebGLRenderingContextBase: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'WebGLRenderingContextBase',
    },
    WebGLRenderingContextOverloads: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'WebGLRenderingContextOverloads',
    },
};
//# sourceMappingURL=webworker.iterable.js.map