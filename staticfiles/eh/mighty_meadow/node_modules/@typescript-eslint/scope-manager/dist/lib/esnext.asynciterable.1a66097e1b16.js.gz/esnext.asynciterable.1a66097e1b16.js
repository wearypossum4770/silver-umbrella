"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.esnext_asynciterable = void 0;
const es2015_symbol_1 = require("./es2015.symbol");
const es2015_iterable_1 = require("./es2015.iterable");
exports.esnext_asynciterable = Object.assign(Object.assign(Object.assign({}, es2015_symbol_1.es2015_symbol), es2015_iterable_1.es2015_iterable), { SymbolConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'SymbolConstructor',
    }, AsyncIterator: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'AsyncIterator',
    }, AsyncIterable: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'AsyncIterable',
    }, AsyncIterableIterator: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'AsyncIterableIterator',
    } });
//# sourceMappingURL=esnext.asynciterable.js.map