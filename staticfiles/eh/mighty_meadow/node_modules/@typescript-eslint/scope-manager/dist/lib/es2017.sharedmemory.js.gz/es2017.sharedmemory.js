"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.es2017_sharedmemory = void 0;
const es2015_symbol_1 = require("./es2015.symbol");
const es2015_symbol_wellknown_1 = require("./es2015.symbol.wellknown");
exports.es2017_sharedmemory = Object.assign(Object.assign(Object.assign({}, es2015_symbol_1.es2015_symbol), es2015_symbol_wellknown_1.es2015_symbol_wellknown), { SharedArrayBuffer: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: true,
        name: 'SharedArrayBuffer',
    }, SharedArrayBufferConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'SharedArrayBufferConstructor',
    }, ArrayBufferTypes: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'ArrayBufferTypes',
    }, Atomics: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: true,
        name: 'Atomics',
    } });
//# sourceMappingURL=es2017.sharedmemory.js.map