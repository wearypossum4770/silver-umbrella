"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.es2019_object = void 0;
const es2015_iterable_1 = require("./es2015.iterable");
exports.es2019_object = Object.assign(Object.assign({}, es2015_iterable_1.es2015_iterable), { ObjectConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'ObjectConstructor',
    } });
//# sourceMappingURL=es2019.object.js.map