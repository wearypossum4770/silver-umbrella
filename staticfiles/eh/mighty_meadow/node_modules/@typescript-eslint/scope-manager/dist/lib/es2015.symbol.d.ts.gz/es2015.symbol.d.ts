import { ImplicitLibVariableOptions } from '../variable';
export declare const es2015_symbol: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2015.symbol.d.ts.map