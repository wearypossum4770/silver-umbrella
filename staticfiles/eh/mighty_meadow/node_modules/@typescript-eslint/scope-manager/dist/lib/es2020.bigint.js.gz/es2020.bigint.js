"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.es2020_bigint = void 0;
exports.es2020_bigint = {
    BigIntToLocaleStringOptions: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'BigIntToLocaleStringOptions',
    },
    BigInt: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: true,
        name: 'BigInt',
    },
    BigIntConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'BigIntConstructor',
    },
    BigInt64Array: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: true,
        name: 'BigInt64Array',
    },
    BigInt64ArrayConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'BigInt64ArrayConstructor',
    },
    BigUint64Array: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: true,
        name: 'BigUint64Array',
    },
    BigUint64ArrayConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'BigUint64ArrayConstructor',
    },
    DataView: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'DataView',
    },
    Intl: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: true,
        name: 'Intl',
    },
};
//# sourceMappingURL=es2020.bigint.js.map