import { ImplicitLibVariableOptions } from '../variable';
export declare const es2020_symbol_wellknown: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2020.symbol.wellknown.d.ts.map