import { ImplicitLibVariableOptions } from '../variable';
export declare const esnext_string: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=esnext.string.d.ts.map