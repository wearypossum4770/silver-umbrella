import { ImplicitLibVariableOptions } from '../variable';
export declare const es2018_full: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2018.full.d.ts.map