"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.es2015_generator = void 0;
const es2015_iterable_1 = require("./es2015.iterable");
exports.es2015_generator = Object.assign(Object.assign({}, es2015_iterable_1.es2015_iterable), { Generator: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'Generator',
    }, GeneratorFunction: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'GeneratorFunction',
    }, GeneratorFunctionConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'GeneratorFunctionConstructor',
    } });
//# sourceMappingURL=es2015.generator.js.map