import { ImplicitLibVariableOptions } from '../variable';
export declare const es2015_reflect: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2015.reflect.d.ts.map