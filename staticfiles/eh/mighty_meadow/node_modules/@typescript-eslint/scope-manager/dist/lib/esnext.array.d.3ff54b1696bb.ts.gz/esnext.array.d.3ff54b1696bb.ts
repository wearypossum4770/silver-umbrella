import { ImplicitLibVariableOptions } from '../variable';
export declare const esnext_array: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=esnext.array.d.ts.map