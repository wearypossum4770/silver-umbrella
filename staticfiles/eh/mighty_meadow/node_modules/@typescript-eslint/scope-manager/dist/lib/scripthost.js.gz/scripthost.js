"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.scripthost = void 0;
exports.scripthost = {
    ActiveXObject: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: true,
        name: 'ActiveXObject',
    },
    ITextWriter: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'ITextWriter',
    },
    TextStreamBase: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'TextStreamBase',
    },
    TextStreamWriter: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'TextStreamWriter',
    },
    TextStreamReader: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'TextStreamReader',
    },
    SafeArray: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: true,
        name: 'SafeArray',
    },
    Enumerator: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: true,
        name: 'Enumerator',
    },
    EnumeratorConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'EnumeratorConstructor',
    },
    VBArray: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: true,
        name: 'VBArray',
    },
    VBArrayConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'VBArrayConstructor',
    },
    VarDate: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: true,
        name: 'VarDate',
    },
    DateConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'DateConstructor',
    },
    Date: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'Date',
    },
};
//# sourceMappingURL=scripthost.js.map