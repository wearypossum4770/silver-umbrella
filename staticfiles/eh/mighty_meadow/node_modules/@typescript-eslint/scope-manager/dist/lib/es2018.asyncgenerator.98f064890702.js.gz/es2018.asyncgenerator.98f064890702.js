"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.es2018_asyncgenerator = void 0;
const es2018_asynciterable_1 = require("./es2018.asynciterable");
exports.es2018_asyncgenerator = Object.assign(Object.assign({}, es2018_asynciterable_1.es2018_asynciterable), { AsyncGenerator: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'AsyncGenerator',
    }, AsyncGeneratorFunction: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'AsyncGeneratorFunction',
    }, AsyncGeneratorFunctionConstructor: {
        eslintImplicitGlobalSetting: 'readonly',
        isTypeVariable: true,
        isValueVariable: false,
        name: 'AsyncGeneratorFunctionConstructor',
    } });
//# sourceMappingURL=es2018.asyncgenerator.js.map