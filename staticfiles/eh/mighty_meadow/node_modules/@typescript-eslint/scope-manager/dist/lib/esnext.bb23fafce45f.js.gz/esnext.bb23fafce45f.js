"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.esnext = void 0;
const es2020_1 = require("./es2020");
const esnext_intl_1 = require("./esnext.intl");
const esnext_string_1 = require("./esnext.string");
const esnext_promise_1 = require("./esnext.promise");
const esnext_weakref_1 = require("./esnext.weakref");
exports.esnext = Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, es2020_1.es2020), esnext_intl_1.esnext_intl), esnext_string_1.esnext_string), esnext_promise_1.esnext_promise), esnext_weakref_1.esnext_weakref);
//# sourceMappingURL=esnext.js.map