import { ImplicitLibVariableOptions } from '../variable';
export declare const es2019: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2019.d.ts.map