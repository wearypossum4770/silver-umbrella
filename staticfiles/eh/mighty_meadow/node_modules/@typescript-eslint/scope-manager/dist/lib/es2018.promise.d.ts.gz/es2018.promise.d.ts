import { ImplicitLibVariableOptions } from '../variable';
export declare const es2018_promise: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=es2018.promise.d.ts.map