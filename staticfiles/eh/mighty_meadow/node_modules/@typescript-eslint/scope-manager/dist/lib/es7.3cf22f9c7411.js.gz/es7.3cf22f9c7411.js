"use strict";
// THIS CODE WAS AUTOMATICALLY GENERATED
// DO NOT EDIT THIS CODE BY HAND
// YOU CAN REGENERATE IT USING yarn generate:lib
Object.defineProperty(exports, "__esModule", { value: true });
exports.es7 = void 0;
const es2015_1 = require("./es2015");
const es2016_array_include_1 = require("./es2016.array.include");
exports.es7 = Object.assign(Object.assign({}, es2015_1.es2015), es2016_array_include_1.es2016_array_include);
//# sourceMappingURL=es7.js.map