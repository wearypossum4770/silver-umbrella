import { ImplicitLibVariableOptions } from '../variable';
export declare const esnext_full: Record<string, ImplicitLibVariableOptions>;
//# sourceMappingURL=esnext.full.d.ts.map